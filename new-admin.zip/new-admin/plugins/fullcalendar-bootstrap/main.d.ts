declare module "@fullcalendar/bootstrap" {
    import { Theme } from "@fullcalendar/core";
    export class BootstrapTheme extends Theme {
    }
    const _default_5: import("@fullcalendar/core/plugin-system").PluginDef;
    export default _default_5;
}